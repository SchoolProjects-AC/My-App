// JavaScript Document


console.log('Start Application');

window.onload = function(){
     
     
     
     //applicationWrapper addition
     var applicationWrapper = document.createElement('div'); 
     applicationWrapper.setAttribute('id', 'appWrap');
     document.body.appendChild(applicationWrapper);
          
     //application header addition
     var applicationHeader = document.createElement('div'); 
     applicationHeader.setAttribute('id', 'appHeader');
     document.getElementById ('appWrap').appendChild(applicationHeader);
     
     //header
     var imageLogo = document.createElement('img');
     imageLogo.setAttribute('id', 'imgLogo');
     imageLogo.src = "assets/images/logo-myapp.png";
     imageLogo.alt = 'MyApp';
     document.getElementById ("appHeader").appendChild(imageLogo);
     
     //application Section
     var applicationSection = document.createElement('div'); 
     applicationSection.setAttribute('id', 'appSection');
     document.getElementById ('appWrap').appendChild(applicationSection);
     
     //application Side
     var applicationSide = document.createElement('div'); 
     applicationSide.setAttribute('id', 'appSide');
     document.getElementById ('appSection').appendChild(applicationSide);
     
     
     //application Content
     var applicationContent = document.createElement('div'); 
     applicationContent.setAttribute('id', 'appContent');
     document.getElementById ('appSection').appendChild(applicationContent);
     imageLogo.src = "assets/images/logo-myapp.png";
     
     //application footer addition
     var applicationFooter = document.createElement('div'); 
     applicationFooter.setAttribute('id', 'appFooter');
     document.getElementById ('appWrap').appendChild(applicationFooter);
    
     
     //nav for the menu
     var navigationMenu = document.createElement('nav');
     navigationMenu.setAttribute('id','navMenu');
     document.getElementById ("appSide").appendChild(navigationMenu);
     
     //ul list to hold the menu
     var navigationList = document.createElement('ul');
     navigationList.setAttribute('id', 'navList');
     
     document.getElementById ("navMenu").appendChild(navigationList);
     
     // dynamically build our menu from JSON
     
     //var menuItems = document.createElement('nav');
     
     for (var key in menuItems){
          if (menuItems.hasOwnProperty(key)) {
               
               var navigationItem = document.createElement('li');
               navigationItem.setAttribute('id', 'navigationItem_' + key);
               navigationItem.setAttribute('class', 'navigationItem');     document.getElementById ("navList").appendChild(navigationItem);
               
               var navlink = document.createElement('a');
               navlink.setAttribute('id', 'navlink_' + key);
               navlink.setAttribute('class', 'navlink');
               navlink.alt = menuItems[key].alt;
               navlink.setAttribute("href", menuItems[key].link);
               
               if (navlink.textContent){
                    navlink.textContent = menuItems[key].title;
               } else {
                    navlink.innerText = menuItems[key].title;
               }
               document.getElementById ("navigationItem_" + key + "").appendChild(navlink);
               document.getElementById ('navlink_' + key).addEventListener("click", menuBuilder);
                    
          }
     }
    
     function menuBuilder() {
          
          iId= this.id.replace('navlink_','');
          var qId = menuItems[iId].content;
          var a = quotes[qId].author;
          var q = quotes[qId].quote;
          
//document.getElementById ("appContent").innerHTML = "YOU CLICKED ME! " + menuItems[this.id.replace('navlink_','')].content;
          
//document.getElementById ("appContent").innerHTML = "YOU CLICKED ME! " + quotes[menuItems[this.id.replace('navlink_','')].content].quote;  
          
          //create wrapper of app
          
         document.getElementById  ('appContent').innerHTML = "";
          
          var x = document.createElement ('div');
          x.setAttribute ('class', 'author');
               if(x.textContent) {
                    x.textContent = quotes[iId].author;
               } else {
                    x.innerText = quotes[iId].author;
               }
          document.getElementById  ('appContent').appendChild(x);
          var y = document.createElement('div');
          y.setAttribute('class', 'quote');
               if (y.textContent) {
                    y.textContent = quotes[iId].quote;
               } else {
                    y.innerText = quotes[iId].quote;
               }
          document.getElementById  ('appContent').appendChild(y);
          

     }
         
     
     
};

