# My-App
This project utilizes JavaScript to create an Application page pulling data from the .json file
